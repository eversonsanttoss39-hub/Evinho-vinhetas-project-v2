# Evinho Files — ponte nativa de exportação

O HTML atual já processa WAV em memória. A camada nativa deve receber **uma faixa por vez** e gravá-la sem passar pelo mecanismo de download do navegador.

## Android
Use MediaStore (Android 10/API 29+) com `RELATIVE_PATH = Download/EVINHO VINHETAS (XX)/` e MIME `audio/wav`. O contador deve procurar as pastas existentes e escolher o próximo número sem sobrescrever uma exportação anterior.

## iOS
O iOS não permite que um app grave silenciosamente na pasta pública Downloads do usuário. O equivalente seguro é salvar em Documents/Exports e oferecer o seletor/compartilhamento do iOS para o usuário escolher Arquivos/Downloads.
