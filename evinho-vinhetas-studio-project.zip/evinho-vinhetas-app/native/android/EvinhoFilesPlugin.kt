package com.evinho.vinhetas.nativebridge

import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.annotation.CapacitorPlugin
import java.util.zip.ZipInputStream
import java.io.ByteArrayInputStream

@CapacitorPlugin(name = "EvinhoFiles")
class EvinhoFilesPlugin : Plugin() {
    @com.getcapacitor.PluginMethod
    fun saveExport(call: PluginCall) {
        val b64 = call.getString("base64") ?: return call.reject("base64 ausente")
        val folder = call.getString("folderName") ?: return call.reject("folderName ausente")
        val fileName = call.getString("fileName") ?: (folder + ".zip")
        try {
            val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$folder")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Não foi possível criar o arquivo")
            resolver.openOutputStream(uri).use { it!!.write(bytes) }
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
            call.resolve(JSObject().put("path", "Download/$folder/$fileName"))
        } catch (e: Exception) {
            call.reject("Falha ao salvar exportação", e)
        }
    }
}
