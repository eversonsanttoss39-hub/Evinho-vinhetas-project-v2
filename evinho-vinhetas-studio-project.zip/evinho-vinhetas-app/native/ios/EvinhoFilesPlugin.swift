import Foundation
import Capacitor
import UniformTypeIdentifiers
import UIKit

@objc(EvinhoFilesPlugin)
public class EvinhoFilesPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "EvinhoFilesPlugin"
    public let jsName = "EvinhoFiles"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "saveExport", returnType: CAPPluginReturnPromise)
    ]

    @objc func saveExport(_ call: CAPPluginCall) {
        guard let b64 = call.getString("base64"), let folder = call.getString("folderName") else {
            call.reject("Dados ausentes"); return
        }
        let fileName = call.getString("fileName") ?? "\(folder).zip"
        guard let data = Data(base64Encoded: b64) else { call.reject("Base64 inválido"); return }
        do {
            let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let dir = root.appendingPathComponent("Exports/\(folder)", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let url = dir.appendingPathComponent(fileName)
            try data.write(to: url, options: .atomic)
            call.resolve(["path": url.path])
        } catch {
            call.reject("Falha ao salvar exportação", nil, error)
        }
    }
}
