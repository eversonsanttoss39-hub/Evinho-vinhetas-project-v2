(function(){
  'use strict';
  // The real Capacitor plugin can expose window.EvinhoFiles.saveExport(base64, folderName).
  // Browser fallback returns false so the original ZIP download continues to work.
  window.EvinhoNativeBridge = {
    async saveExport(blob, folderName){
      try{
        if(window.EvinhoFiles && typeof window.EvinhoFiles.saveExport === 'function'){
          const buf = await blob.arrayBuffer();
          let binary='';
          const bytes=new Uint8Array(buf);
          const chunk=0x8000;
          for(let i=0;i<bytes.length;i+=chunk){binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));}
          const base64=btoa(binary);
          await window.EvinhoFiles.saveExport({base64, folderName, fileName: folderName+'.zip'});
          return true;
        }
      }catch(e){ console.error('Evinho native export:',e); }
      return false;
    }
  };
})();
