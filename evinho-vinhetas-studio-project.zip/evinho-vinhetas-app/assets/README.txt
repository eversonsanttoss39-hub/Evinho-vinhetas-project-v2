icon-1024.png: arte principal para ícone/App Store.
splash-2048.png: arte principal para tela de abertura.
