# Evinho Vinhetas — Studio

Projeto base multiplataforma a partir do `Evinho-Vinhetas-PRO.html` enviado pelo usuário.

## O que já está preservado
- Interface Evinho Vinhetas
- Até 200 músicas
- Até 2 vinhetas
- Pré-escuta
- Detecção de ponto automático/manual
- Ducking
- Processamento em lote, uma faixa por vez
- Exportação WAV
- Numeração `EVINHO VINHETAS (01)`, `(02)` etc.

## Próxima camada do app
A ponte nativa em `native/` substitui o download do navegador. No Android, a exportação final deve ir para `Download/EVINHO VINHETAS (XX)/`. No iOS, usar Documents/Exports + seletor Arquivos, porque o iOS não permite escrita silenciosa na pasta pública Downloads.

## Arte
A imagem fornecida pelo usuário foi usada como arte principal em `assets/icon-1024.png` e `assets/splash-2048.png`.

## Build
1. Instale Node.js e npm.
2. `npm install`
3. `npx cap add android` e/ou `npx cap add ios`
4. `npx cap sync`
5. Android: abrir no Android Studio e gerar APK/AAB.
6. iOS: abrir no Xcode em macOS, configurar assinatura e Archive.

Observação: o ambiente desta entrega não possui Android SDK nem macOS/Xcode, portanto não foi possível gerar aqui um APK/IPA assinado. O projeto e os assets estão preparados para essa etapa.
